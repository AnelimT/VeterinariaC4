module.exports = {
  extends: '@loopback/eslint-config',
};
