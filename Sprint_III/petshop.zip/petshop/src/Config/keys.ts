export namespace Keys{
    export const JWT = 'JWT@2022';
    export const urlNotificacion= 'http://localhost:5000';
    export const email_origin = 'soporte@princesspetshop.com.co';
    export const subject = '[creación cuenta de usuario]Mensaje de bienvenida'
}
