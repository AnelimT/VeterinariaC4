export namespace GeneralData{
    export const ADMIN_USERS_URL ="htto://localhost:4200"
    export const BUSSINESS_URL="htto://localhost:4200"
    export const EMAIL_MIN_LENGHT= 6
    export const PASSWORD_MIN_LENGHT= 6
    export const PASSWORD_MAX_LENGHT= 18
    export const INVALID_FORM_MESSAGE="ERROR"
    export const RECORDS_BY_PAGE=10
    
}