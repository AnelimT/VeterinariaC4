export class UserCredentials{
    email?: string;
    password?: string;
}