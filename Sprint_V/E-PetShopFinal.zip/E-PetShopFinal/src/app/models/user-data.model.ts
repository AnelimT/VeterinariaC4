export class UserData{
    _id?: string;
    email?: string;
    name?: string;
}