import { Component, OnInit } from '@angular/core';

declare const OpenGeneralMessageModal: any;
declare const initSelecvtById: any;

@Component({
  selector: 'app-create-product',
  templateUrl: './create-product.component.html',
  styleUrls: ['./create-product.component.css']
})
export class CreateProductComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
